const { Pool } = require("pg");
const p = new Pool({ host: "localhost", port: 5432, user: "thiqti", password: "thiqti_secret", database: "thiqti", connectionTimeoutMillis: 4000 });
p.connect()
  .then((c) =>
    c.query("SELECT count(*) AS v FROM vehicles")
      .then((r) => console.log("vehicles:", r.rows[0].v))
      .then(() => c.query("SELECT count(*) AS r FROM reviews").then((r) => console.log("reviews:", r.rows[0].r)))
      .then(() => c.query("SELECT count(*) AS s FROM reputation_scores").then((r) => console.log("scores:", r.rows[0].s)))
      .finally(() => p.end())
  )
  .catch((e) => console.log("ERR:", e.message));
