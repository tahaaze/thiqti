"use client";

import { useState, type ReactNode } from "react";
import { Calendar, Gauge, Tag, Fuel } from "lucide-react";
import { ThiqtiShield } from "@/components/icons";
import { SearchFilters, SearchFacets, countActiveFilters } from "@/lib/searchTypes";

const PRICE_PRESETS = [
  { label: "≤ 100k", value: 100000 },
  { label: "≤ 150k", value: 150000 },
  { label: "≤ 250k", value: 250000 },
  { label: "≤ 400k", value: 400000 },
  { label: "≤ 600k", value: 600000 },
];

const SAFETY_OPTIONS = [
  { label: "3★ minimum", value: 3 },
  { label: "4★ minimum", value: 4 },
  { label: "5★", value: 5 },
];

interface FilterPanelProps {
  facets: SearchFacets;
  filters: SearchFilters;
  total: number;
  onChange: (filters: SearchFilters) => void;
  onReset: () => void;
}

function Slider({
  label,
  icon: Icon,
  min,
  max,
  step,
  value,
  display,
  onChange,
}: {
  label: string;
  icon: typeof Calendar;
  min: number;
  max: number;
  step: number;
  value: number;
  display: string;
  onChange: (v: number) => void;
}) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between">
        <span className="flex items-center gap-1 text-xs text-muted">
          <Icon className="h-3.5 w-3.5 text-primary" />
          {label}
        </span>
        <span className="rounded-md bg-primary/10 px-2 py-0.5 text-xs font-semibold text-primary">{display}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-primary"
      />
    </div>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full border px-3 py-2 text-[11px] font-bold uppercase tracking-wider transition ${
        active
          ? "border-primary bg-primary/15 text-primary"
          : "border-line text-muted hover:border-primary/40 hover:text-ink"
      }`}
    >
      {children}
    </button>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="border-t border-line pt-4">
      <p className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted">{title}</p>
      {children}
    </div>
  );
}

export default function FilterPanel({ facets, filters, total, onChange, onReset }: FilterPanelProps) {
  const [priceQuery, setPriceQuery] = useState("");

  const activeCount = countActiveFilters(filters);
  const maxYear = facets.yearMax || 2026;
  const minYear = facets.yearMin || 2018;
  const year = filters.minYear ?? minYear;
  const km = filters.maxKm ?? 250000;

  const set = (patch: Partial<SearchFilters>) => onChange({ ...filters, ...patch });
  const toggle = (key: keyof SearchFilters, value: string | number) => {
    const next: SearchFilters = { ...filters };
    if (next[key] === (value as never)) delete next[key];
    else (next[key] as unknown) = value;
    onChange(next);
  };

  const pricePresetActive = PRICE_PRESETS.some((p) => p.value === filters.maxPrice && !filters.minPrice);
  const safetyActive = (v: number) => filters.minSafety === v;

  const filteredBrands = facets.brands.filter((b) =>
    b.toLowerCase().includes(priceQuery.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="rounded-xl bg-primary/5 px-4 py-3 text-center">
        <p className="text-xs text-muted">Résultats</p>
        <p className="text-lg font-bold text-primary">{total}</p>
      </div>

      <Section title="Budget">
        <div className="mb-3 flex flex-wrap gap-1.5">
          {PRICE_PRESETS.map((p) => (
            <Chip key={p.value} active={pricePresetActive && filters.maxPrice === p.value} onClick={() => set({ maxPrice: p.value, minPrice: undefined })}>
              {p.label}
            </Chip>
          ))}
          <Chip active={!filters.maxPrice && !filters.minPrice} onClick={() => set({ maxPrice: undefined, minPrice: undefined })}>
            Tous
          </Chip>
        </div>
        <div className="flex items-center gap-2">
          <input
            type="number"
            placeholder="Min (DH)"
            value={filters.minPrice ?? ""}
            onChange={(e) => set({ minPrice: e.target.value ? Number(e.target.value) : undefined })}
            className="input-field text-sm"
          />
          <span className="text-muted">—</span>
          <input
            type="number"
            placeholder="Max (DH)"
            value={filters.maxPrice ?? ""}
            onChange={(e) => set({ maxPrice: e.target.value ? Number(e.target.value) : undefined })}
            className="input-field text-sm"
          />
        </div>
      </Section>

      <Section title="Année minimum">
        <Slider
          label=""
          icon={Calendar}
          min={minYear}
          max={maxYear}
          step={1}
          value={year}
          display={String(year)}
          onChange={(v) => set({ minYear: v })}
        />
      </Section>

      <Section title="Kilométrage max">
        <Slider
          label=""
          icon={Gauge}
          min={0}
          max={250000}
          step={5000}
          value={km}
          display={km >= 250000 ? "Indifférent" : `${km.toLocaleString("fr-FR")} km`}
          onChange={(v) => set({ maxKm: v === 250000 ? undefined : v })}
        />
      </Section>

      <Section title="Sécurité (crash test)">
        <div className="flex flex-wrap gap-1.5">
          <Chip active={!filters.minSafety} onClick={() => set({ minSafety: undefined })}>
            Toutes
          </Chip>
          {SAFETY_OPTIONS.map((o) => (
            <Chip key={o.value} active={safetyActive(o.value)} onClick={() => toggle("minSafety", o.value)}>
              <span className="inline-flex items-center gap-1">
                <ThiqtiShield className="h-3 w-3" />
                {o.label}
              </span>
            </Chip>
          ))}
        </div>
        <p className="mt-2 text-[10px] text-muted">
          Basé sur Euro NCAP / NHTSA · {facets.safety.evaluated} modèles notés, {facets.safety.fiveStars} au maximum
        </p>
      </Section>

      <Section title="Carrosserie">
        <div className="flex flex-wrap gap-1.5">
          <Chip active={!filters.bodyType} onClick={() => set({ bodyType: undefined })}>
            Toutes
          </Chip>
          {facets.bodyTypes.map((b) => (
            <Chip key={b} active={filters.bodyType === b} onClick={() => toggle("bodyType", b)}>
              {b}
            </Chip>
          ))}
        </div>
      </Section>

      <Section title="Motorisation">
        <div className="flex flex-wrap gap-1.5">
          <Chip active={!filters.fuel} onClick={() => set({ fuel: undefined })}>
            Toutes
          </Chip>
          {facets.fuels.map((f) => (
            <Chip key={f} active={filters.fuel === f} onClick={() => toggle("fuel", f)}>
              <span className="inline-flex items-center gap-1">
                <Fuel className="h-3 w-3" />
                {f}
              </span>
            </Chip>
          ))}
        </div>
      </Section>

      <Section title="Marque">
        <div className="relative">
          <Tag className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted" />
          <input
            type="text"
            value={priceQuery}
            onChange={(e) => setPriceQuery(e.target.value)}
            placeholder="Rechercher une marque…"
            className="input-field pl-9 text-sm"
          />
        </div>
        <select
          value={filters.brand ?? ""}
          onChange={(e) => set({ brand: e.target.value || undefined })}
          className="mt-2 w-full input-field text-sm"
        >
          <option value="">Toutes les marques</option>
          {filteredBrands.map((b) => (
            <option key={b} value={b}>
              {b}
            </option>
          ))}
        </select>
      </Section>

      <Section title="Ville">
        <select
          value={filters.city ?? ""}
          onChange={(e) => set({ city: e.target.value || undefined })}
          className="w-full input-field text-sm"
        >
          <option value="">Toutes les villes</option>
          {facets.cities.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </Section>

      {activeCount > 0 && (
        <button
          onClick={onReset}
          className="flex w-full items-center justify-center gap-2 rounded-xl border border-line py-2.5 text-sm text-muted transition hover:border-primary/40 hover:text-ink"
        >
          Effacer {activeCount} filtre{activeCount > 1 ? "s" : ""}
        </button>
      )}
    </div>
  );
}
